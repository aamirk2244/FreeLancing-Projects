package Registration;


import show_all_Person.People;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Registration_Gui implements ActionListener {
    public  JPanel panel;
    public JButton Register_person;
    public  JButton allPersonListButton;

    public JLabel head_label;
    public JFrame frame;
    public void setActionCommand()
    {
        Register_person.setActionCommand("1");         // register person
        allPersonListButton.setActionCommand("2");    // all person list

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getActionCommand() == "1")     // button register student has been clicked
        {
            Add_Person.main(frame);
            System.out.println("ist button is clicked");
//            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
//            frame.dispose();
            return;
        }
        if(e.getActionCommand() == "2")
        {
            People show = new People();
            show.main_of_Person( frame);
//            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


//            frame.dispose();
            return;
        }
    }
    public static void main()
    {
        String header = "Registration";
        Registration_Gui LOGIN = new Registration_Gui();
        LOGIN.head_label.setText(header);
        LOGIN.frame = new JFrame();
        LOGIN.frame.setSize(800, 300);
        LOGIN.frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        LOGIN.frame.setContentPane(LOGIN.panel);    // to add the panel to the frame
        LOGIN.frame.setVisible(true);
        LOGIN.Register_person.addActionListener(LOGIN);
        LOGIN.allPersonListButton.addActionListener(LOGIN);
        LOGIN.setActionCommand();
    }
}
