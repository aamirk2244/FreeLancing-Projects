package Registration;
import com.opencsv.CSVWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class csvObject {
    public void DoInsertion(String[] data, boolean append ) {
        System.out.println("inserting this data ");
        System.out.println(data.toString());
        String filePath = "src/com/proj/people_list.csv";
        System.out.println("inserting this data " + data);
        File file = new File(filePath);
        FileWriter outputfile;
        try {
            // create FileWriter object with file as parameter
            if (append == false)
                outputfile = new FileWriter(file, false);
            else
                outputfile = new FileWriter(file, true);


            // create CSVWriter object filewriter object as parameter

            CSVWriter writer = new CSVWriter(outputfile);
            System.out.println("Inserting this data in CSV obj file");
            System.out.println(data);
            writer.writeNext(data);



            // closing writer connection
            writer.close();
        }
        catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}