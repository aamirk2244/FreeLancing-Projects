package Registration;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class Add_Person implements ActionListener {
    private JPanel panel1;
    private JTextField textAge;
    private JTextField Name;
    private JButton enterButton;
    private JTable table1;
    private JLabel error_label;
    private JTextField cnicTextField;
    public DefaultTableModel model;
    public String registerDate;


    public Add_Person() {
        Name.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER)           // adding key event to detect if enter key is pressed
                {
                    button_or_enter_is_pressed();
                }
            }
        });
        textAge.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER)
                {
                    button_or_enter_is_pressed();
                }
            }
        });
    }

    private void createTable(){

        Object[][] data = {
                {"Example Name", "0", "0", "yyyy/MM/dd HH:mm:ss"},                        // dummy example row
        };
        table1.setModel(new DefaultTableModel(
                data,
                new String[]{"Person Name", "Age", "National Identification Number", "Date"}
        ));

        TableColumnModel columns = table1.getColumnModel();
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for(int i = 0; i < 4; i++)
        {
            columns.getColumn(i).setCellRenderer(centerRenderer);   // setting every column to center
        }
    }
    public static void main(JFrame tmp_frame)
    {
        tmp_frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
//        tmp_frame.dispose();
        Add_Person add = new Add_Person();
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setContentPane(add.panel1);
        frame.setSize(1500, 500);
        frame.setLocationRelativeTo(null);
        add.enterButton.addActionListener(add);
        add.createTable();
        frame.setVisible(true);

    }
    private void button_or_enter_is_pressed()
    {
        String person_name_field = Name.getText();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        registerDate = dtf.format(now);


        String Student_age_field = textAge.getText();
        String personCnic  = cnicTextField.getText();
        String regex = "^[ a-zA-Z]+$";       // for validating string
        int len_of_age_field = Student_age_field.length();
        if(len_of_age_field == 0 || person_name_field.length() == 0)
        {
            error_label.setText("Please fill all fields");
        }
        else if (!(person_name_field.matches(regex))) {
            error_label.setText("Person Name is Invalid");
        }
        else if(person_name_field.length() <= 2)
        {
            error_label.setText("Name is too short");
        }
        else if(len_of_age_field < 1 || len_of_age_field >  112)               // some threshold for age
        {
            textAge.setText("");
            error_label.setText("Invalid Age");
        }

        else
        {
            // first create file object for file placed at location
            // specified by filepath
            csvObject ParentCl;
            ParentCl = new csvObject();
            String[] data1 = { person_name_field, Student_age_field, personCnic, registerDate};

            ParentCl.DoInsertion(data1,true);
            error_label.setText("Person Registered Successfully");
            textAge.setText("");
            Name.setText("");
            DefaultTableModel model = (DefaultTableModel) table1.getModel();
            model.addRow(new Object[]{person_name_field, Student_age_field, personCnic, registerDate});

        }

    }
        @Override
    public void actionPerformed(ActionEvent e)  {

        button_or_enter_is_pressed();

    }

}
