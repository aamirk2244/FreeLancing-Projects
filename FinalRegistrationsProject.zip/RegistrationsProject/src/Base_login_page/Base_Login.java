package Base_login_page;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Base_Login implements ActionListener {
    private JLabel Base_Login;
    private JPanel Start;
    private JButton Login_Registration;

    public JPanel create_Base_page()
    {
        return Start;
    }
    public void start_base_page()
    {
        Login_Registration.setActionCommand("r");                // event registration
        Login_Registration.addActionListener(new Base_Login());
    }

    @Override
    public void actionPerformed(ActionEvent e) {        // if click on button

        if(e.getActionCommand() == "r")
        {
            make_login_page("Let's go to Registration Panel", 'r');
            return;
        }

    }
    public void make_login_page (String header, char name)
    {
        System.out.println("this is head " + header);
        Login_Password_GUI.main(header,name );
    }


}
