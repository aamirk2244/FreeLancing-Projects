package show_all_Person;

import Registration.csvObject;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
public class People implements ItemListener, ActionListener {
    private DefaultTableModel model;
    private JLabel head_text;
    private JTable table1;
    private JComboBox comboBox1;
    private JLabel age;
    private JPanel panel;
    private JLabel TotalPerson_label;
    private JButton removePerson;
    private int totalPerson = 0;
    private  List<String> get_row;
    private String registerDate;


    public String[] s = new String[13];

    public void set_person_ageLimits()
    {

       for(int i = 0; i < 13; i++)
       {
           if(i == 0)
           {
               s[i] = "Select Specific Age";
           }
           else
           {

               s[i] = i * 10 + " to " + i * 20;       // for setting age limit, means if i = 1 then 1 * 10= 10 to 1 * 20 = 20, means age limit for this iteration is 10 to 20
           }
       }
    }
    public void create_table(String Name, String age, String CNIC, String registerDate)
    {
        table1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        String[] column = {Name, age,CNIC , registerDate};
        Object[][] data = null;
        table1.setModel(new DefaultTableModel(data, column));
       table1.setShowGrid(true);
    }

    public void set_frame(String heading)
    {
        JFrame frame = new JFrame();
        panel.setLayout(new FlowLayout());
        head_text.setText(heading);
        frame.setVisible(true);
        frame.setSize(800, 700);
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        frame.setContentPane(panel);
        removePerson.addActionListener(this);



        age.setText("Age");
            for(int i = 0 ; i < 13; i++)
            {
                comboBox1.addItem(s[i]);
                if(i != 0)
                {
                    comboBox1.getItemAt(i); // for choosing age limit with combobox, adding rows

                }

            }
         comboBox1.addItemListener(this);        // when any  age limit is selected


    }


    public void main_of_Person(JFrame temp_frame, boolean flag)
    {
        temp_frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        System.out.println("here User list");
//        temp_frame.dispose();
        set_person_ageLimits();          // adding combobox of age

            set_frame("Users List");         // adding heading of frame
            show_people_with_age(0);


    }
    // method overloading for default argument
    public void main_of_Person(JFrame temp_frame)
    {
        main_of_Person(temp_frame, false);

    }
    private void show_people_with_age(int number)
    {
        String position = Integer.toString(number);
        get_row = new ArrayList<String>();


            if(number == 0)
            {
                try{
                    BufferedReader br = new BufferedReader(new FileReader("src/com/proj/people_list.csv"));
                    String line;
                    while ((line = br.readLine()) != null) {
                        // use comma as separator
                        String[] cols = line.split(",");
                        get_row.add(cols[0].replaceAll("^\"+|\"+$", ""));                   // name, i.e ist column in csv file
                        get_row.add(cols[1].replaceAll("^\"+|\"+$", ""));                           // 2nd column in csv file which is age
                        get_row.add(cols[2].replaceAll("^\"+|\"+$", ""));
                        get_row.add(cols[3].replaceAll("^\"+|\"+$", ""));
                    }
                    br.close();

                    } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
            else
            {
                try{
                    BufferedReader br = new BufferedReader(new FileReader("src/com/proj/people_list.csv"));
                    String line;

                    while ((line = br.readLine()) != null) {
                        // use comma as separator
                        String[] cols = line.split(",");
                        String l= cols[1];      // converting age value to string
                         l = l.replaceAll("^\"+|\"+$", "");    // concerting json format string to normal one
                        int Age = Integer.parseInt(l);
                         if (number <= Age  && Age <= (number/10) * 20 )                    // for re ordering formula to get the specific users in the range
                        {
                            get_row.add(cols[0].replaceAll("^\"+|\"+$", ""));                   // name, i.e ist column in csv file
                            get_row.add(cols[1].replaceAll("^\"+|\"+$", ""));                           // 2nd column in csv file which is age
                            get_row.add(cols[2].replaceAll("^\"+|\"+$", ""));
                            get_row.add(cols[3].replaceAll("^\"+|\"+$", ""));

                        }

                    }
                    br.close();


                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


            String NAME;
            String age;
            String personCnic;

                create_table("Name ","Age", "National Identification Number", "Date");
              model = (DefaultTableModel) table1.getModel();

                int i = 0;
                int totalLength = get_row.size();
                while(i < totalLength)
                {

                    NAME = get_row.get(i);          // name present at ist value and age present at 2nd value
                    i += 1;
                    age = get_row.get(i);

                    i+= 1;
                    personCnic = get_row.get(i);
                    i += 1;
                    registerDate = get_row.get(i);
                    i+= 1;
                    model.addRow(new Object[]{NAME, age, personCnic, registerDate});
                    totalPerson += 1;
                }
                TotalPerson_label.setText("Total Users are " + totalPerson );

        TableRowSorter<TableModel> sorter = new TableRowSorter<>(table1.getModel());
        table1.setRowSorter(sorter);
        List<RowSorter.SortKey> sortKeys = new ArrayList<>(25);
        sortKeys.add(new RowSorter.SortKey(0, SortOrder.ASCENDING));      // sorting first column

        sorter.setSortKeys(sortKeys);

    }

    @Override
    public void itemStateChanged(ItemEvent e) {
//        System.out.println("ITEM LISTENER PRESSED");

        for(int i = 0 ; i < 13; i++)
        {
            if(e.getItem() == s[i])
            {
                int current_age_is = i * 10;


                show_people_with_age(current_age_is);
            }
        }

    }


    @Override
    public void actionPerformed(ActionEvent event) {
        // do nothing for now although event is registered
        System.out.println("button clicked");
        if(table1.getSelectedRow() != -1) {
            // remove selected row from the model

//            deleteRowCnic = (String[]) model.getValueAt(table1.getSelectedRow(), 2);       // saving cnic of the deleted row to delete from the file too
            String deleteRowCnic = model.getValueAt(table1.getSelectedRow(), 2).toString();
            System.out.println("deleting this row ---------------------");
            System.out.println(deleteRowCnic);
            model.removeRow(table1.getSelectedRow());                  // deleting row from the UI table
            JOptionPane.showMessageDialog(null, "Selected row deleted successfully");
            totalPerson -= 1;
            TotalPerson_label.setText("Total Users are " + totalPerson );

            ///////////////// now deleting from file as well
            get_row = new ArrayList<String>();
            try {

                BufferedReader br = new BufferedReader(new FileReader("src/com/proj/people_list.csv"));
                String line;

                while ((line = br.readLine()) != null) {
                    // use comma as separator
                    String[] cols = line.split(",");
                    cols[2] =  cols[2].replaceAll("^\"+|\"+$", "");
//                    System.out.println("here checking");
//                    System.out.println(cols[0]);
                    String l = cols[1];      // converting age value to string
                    l = l.replaceAll("^\"+|\"+$", "");    // concerting json format string to normal one
//                    System.out.println("this is l " + l);

                    int clAss = Integer.parseInt(l);
                    if (!(cols[2].equals(deleteRowCnic)))                    // skipping the deleted row
                    {
//                        System.out.println("this is cols[0], cols[1], and last is deleteRow ");
//                        System.out.println(cols[0]);
//                        System.out.println(cols[2]);
//                        System.out.println(deleteRowCnic);

                        get_row.add(cols[0].replaceAll("^\"+|\"+$", ""));                   // name, i.e ist column in csv file
                        get_row.add(cols[1].replaceAll("^\"+|\"+$", ""));                           // 2nd column in csv file which is age
                        get_row.add(cols[2].replaceAll("^\"+|\"+$", ""));
                    }

                }
                br.close();
            }
            catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
//
//
//
//
//
        }
        System.out.println("priting whole rows");
        System.out.println(get_row);

        csvObject ParentCl;
        ParentCl = new csvObject();
        String person_name_field, Person_age_field, personCnic;
        String[] data1;
        System.out.println(get_row.size());
        boolean append;

        for(int i = 0 ; i < get_row.size(); i+=3)
        {
            if(i == 0){append = false;}
                else{append = true;}
                    person_name_field = get_row.get(i);
                Person_age_field = get_row.get(i + 1);
                personCnic = get_row.get(i + 2);

                data1 = new String[]{person_name_field, Person_age_field, personCnic, registerDate};
                ParentCl.DoInsertion(data1,append);               // for the first time , append will be false


        }





    }

}
