from operator import index
import socket
import os 
from wsgiref import validate

c = socket.socket()
c.connect(('localhost', 7269))  


#Name: Mohammed Amin Bin Norashid
#Student ID: P7398944
#PSEC ASSIGNMENT 1


def presentServices(): # returning services in the form of dictionary
    return {'Firewall Service': 1.2, 
                'Security Ops Centre': 4.2,
                'Hot Site': 8.5,
                'Data Protection': 10.0
               }

def addServices(service = None):
    if service is None:     
        service = presentServices()

    serviceName = list(service)               # this contain all service names 
    added = []
    getInput = '-1'                           # initializing with dummy value
    service_length = len(service)
    while  getInput != '0':
        getInput = input('Enter the service 1-{} that you would like to add, or 0 to stop:'.format(service_length))     # this is for the total services shown. It will output the users services list

        if getInput == '0' or getInput == '':continue           # stopping the loop

        if int(getInput) < 1 or int(getInput) > service_length:
            print('Invalid Value: Enter valid Input')
            input('Enter to continue ..')
            continue
        added.append(serviceName[int(getInput)-1])          # adding the user selected service to the added list
        print(getInput + ' added')
    
    return added
        
def getAddedServices(services = None):
    return addServices(services)                # to call addServices function and directly returning services which the user added in that function

def displayServices(services): 
    serviceIndex = 1                            # for service number
    
    for values in services:
        serviceName = values                    # getting key and value from the dictionary , services
        amount = services[values]
        # 1. Firewall Service	:	 $1.2k/year   # printing in this format 
        if serviceName == "Hot Site" : serviceName += '\t'   # adding tab to service name Hot service because it is affecting our padding
        
        print("{}. {}\t\t:\t ${}k/year".format(serviceIndex,serviceName,amount) ) # {} the placeholder for the variables to print in required manner , .format function takes the variables to insert into the placeholder
        serviceIndex += 1
        
def payment(serviceAdded):                      # payment function
    defaultServices = presentServices()
    print('Please check your services added:\n\n')
    to_dict = {}
    for val in serviceAdded:
        to_dict[val] = defaultServices[val]                # converting the added services list to dictionary to show the equivalent amount
   
    displayServices(to_dict)                               # displaying the added services 

    totalSum = sum(list(map(lambda service : defaultServices[service], serviceAdded  )))  # adding total of all added services     
    if totalSum == 0:
        print('No Services added yet')
        return
    print('Your subscription will be a total of : ${}k/year.'.format(totalSum))
    print('Thank you for using ESP.')
    input('Press enter to continue')

def Search(services):                           # search function
    serviceNames = services.keys()

    userSearch = input('please enter service to search: ')
    userSearch = userSearch.lower()
    foundServices = {}
    tempName = ''
    for names in serviceNames:
        tempName = names.lower()          # working with both upper and lower case search
        if userSearch in tempName:
            foundServices[names] = services[names]        # key will be the service name and the value will be the amount of that service
    
    if len(foundServices) == 0 : 
        print('No services found ')
        input('press Enter to continue ..')
    else:
        displayServices(foundServices)
        return foundServices
def removeSubscription(pin):
    getinput = input('enter index from your services to remove, note that index start from 0, i.e 0 is the first line, 0th line : ')
    
    fileName = pin + '.txt'
    myStr = ''
    f= open(fileName, 'r')
    while True:
        line = f.readline()
        if not line:break
        myStr += line
    get = myStr.split('\n')
    print('removing from this list ')
    get.pop(-1)
    get.pop(-1)
    get.pop(int(getinput))

    f = open(fileName, "w")
    f.writelines([i+'\n' for i in get])             # inserting subscriptions to the file

    f.close()
    
def addServiceSubs(pin):
    getinput = input('enter index from all service list to add, note that the services which are already add should not be add again, enter index of those services which are not present in your subscrptions : ')
    # error is not handled hear , make sure you enter correct index
    fileName = pin + '.txt'
    myStr = ''
    f= open(fileName, 'w')
    while True:
        line = f.readline()
        if not line:break
        myStr += line
    get = myStr.split('\n')
   
    getServices = presentServices()
    elements = list(getServices.keys())
    get.insert(0, elements[int(getinput)])

    f = open(fileName, "w")
    f.writelines([i+'\n' for i in get])             # inserting subscriptions to the file

    f.close()
    

def editSubscription(services, pin):
    getinput = input('enter a for add servies or r for removing service')
    if getinput == 'r' or getinput == 'R':
        removeSubscription(pin)
    elif getinput == 'a' or getinput == 'A':
        addServiceSubs(pin)



def showHome():                                # home function

    print('============================================')
    print('Welcome to Electronic Services & Protection:')
    print('============================================')
    print('\t 1. Display Our List of Services')
    print('\t 2. Search for Services')
    print('\t 3. Display your services and subscription or add , delete service')
    print('\t 4. Payment')
    print('\t 5. Exit ESP and save your Subscriptions')


def validateUser():
    getId = '' 
    while True:
        getId = input('\t Enter your 4 digit PIN  ')
        if getId.isnumeric() and len(getId) == 4:break
        else:
            print('Invalid PIN')
            continue
    return getId
    
def saveUser(added_service, services):
    getId = validateUser()
    print('addes servie*****************')
    print(added_service)
    print('sending services to server')

    if len(services) ==0 :
        print('returning ')
        return
    sendData = ''
    for services in added_service:
        sendData = sendData +  services + ','
        print('sending this -> ', services)
    sendData += getId
    print('sending this ', sendData)
        
    c.send(sendData.encode())



    
    
def startMain():                              # main home page function
    added_service = None
    services = presentServices()
    
    print()
    newUser = False
    loggedUser = ''
    while True:
        getInput = input('\tEnter 1 to enter your PIN to LOGIN or 2 If new user: ') # taking input 
        if getInput == '2':
            newUser = True
            break
        elif getInput == '1':
            getId = validateUser()
            userId = getId
            getId = '?0' + getId
            print('sending PIN to server')
            c.send(getId.encode())
            data=  c.recv(1024).decode()
            if data[0] != 'P':        # if login incorrect
                print('error')
                print(data)
            else :
                print('Login successfull...')
                newUser = False
                loggedUser = userId
                break
        
            

    while True:
        showHome()                            # call home function
        
        getInput = input('\t Please input your choice of action: ') # taking input 
    

        if getInput == '1':                   # call for display service list
            print('Yes, we have the following service(s):')
            
            if newUser:
                displayServices(services)
                added_service =  getAddedServices()
            
                if added_service == '0':          # if the user wants to stop 
                    clearConsole()                # clear the whole console
            else:
                displayServices(services)


        
        elif getInput == '2':                 # call for search 
            foundS = Search(services)
            if foundS is not None:
                print('Yes, we have the following service(s):')

                added_service =  getAddedServices(foundS)
           
        elif getInput == '3':                 # call for added service 
            if newUser and added_service is None: 
                print("New User. No services and subscriptions yet")
                continue
            elif newUser and added_service is not None:
                print(added_service)
            
            displayServices(services)
            getId = loggedUser
            getId  = '?3' + getId
            #recv something
            print('sending PIN data to server ', getId)

            c.send(getId.encode())                 # getting data from server by sending our pin

            print('reached here')
            data = c.recv(1024).decode()
            print('recieved data from server ')
            print('*********************** client have subscribed to these services ******************************\n', data)
        
            getOpt = input('\n\tDo you want to Edit Subscription ? Press y for yes or n for no..')
            if getOpt == 'y' or getOpt == 'Y':editSubscription(services, loggedUser)

        
        elif getInput == '4':                 # call for payment
            if not newUser:
                sendata = '?4' + loggedUser
                print('sending this to server ', sendata )
                c.send(sendata.encode())                # sending user's PIN to server
                data = c.recv(5024).decode()
                
                # print('this data is received from server ', data)
                
                data = data.split('\n')
                data.pop(-1)           # cleaning  data
                data.pop(-1)
                
                added_service = None
                added_service = data.copy()
            else:
                getId = validateUser()
                getId  = '?4' + getId
                #recv something
                print('sending PIN data to server ')

                c.send(getId.encode())


                data = c.recv(1024).decode()
                print('recieved data from server ==> ', data)
                print('printing ist index :: ', data[0])
            
                print('this is added servies ', added_service)      
            if added_service is not None: payment(added_service)
            else : print('No Services added yet')
        
        elif getInput == '5':                 # call to end program
            if added_service is not None and newUser:  
                print('You are  new User,  Save your Subscriptions')
                saveUser(added_service, services)  
            
            elif not newUser:
                print('You are Our registered user, Your subscriptions are already saved.')

            input('Thank you for using ESP. Hope to see you again!')
            return  

        elif getInput == '':                  # invalid input
               
            continue
        else : print('Invalid Input..')      
    

startMain()