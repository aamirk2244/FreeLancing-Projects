import socket
import os
from datetime import datetime


s = socket.socket()         # by default it is tcp and ipv4
print('socket created')
s.bind(('localhost', 7269))    # ip with port number
s.listen(5)         # max 1 connections 
print('wating for connection')
data = ''
myStr = ''
def makeFile(data):
    fileName = data[2:]
    fileName = './' + fileName + '.txt'
    if not os.path.exists(fileName):return None
    fileName = fileName[2:]
    return fileName
def readFile(fileName):
    myStr = ''
    f= open(fileName, 'r')
    while True:
        line = f.readline()
        if not line:break
        myStr += line
    return myStr

def addServices(data):
    l = data.split(',')
    dateTimeObj = datetime.now()

    l.append(str(dateTimeObj.date()))
    fileName = l[-2]                         # pin contains on 2nd last index which will also be the file name as well  
    fileName += '.txt'
    l.pop(-2)
    fileName = fileName[2:]
    
    print('creating this file ', fileName)
    f = open(fileName, "w")
    f.writelines([i+'\n' for i in l])             # inserting subscriptions to the file

    f.close()



c, addr =  s.accept() # accepting from client, returns client socket and address of the client

    
while True:
    print('connected with , ', addr)
    data = c.recv(1024).decode()
        

    print('/////////////////////// PIN  is received from client ////////////////////////// ', data)
    if data[0] == '?' and data[1] == '3':  # it means that user want to  display subscription 
        fileName =makeFile(data)
        if fileName is None:
            print('******* no user found ************************************')
            c.send('no user found'.encode())
            continue
        else:   
            print('user found in server')
            myStr = ''        # if user found
            print('this is file name ', fileName)
            myStr = readFile(fileName)

            print('sending to client ---> ', myStr)
            c.send(myStr.encode())
    
    if data[0] == '?' and data[1] == '4':  # it means that user want to  display payment
        print('preparing')
        fileName =makeFile(data)
        if fileName is  None:
            print('*************no user found ***************')
            c.send('no user found'.encode())
            continue
        else:
            myStr = ''
            myStr = readFile(fileName)
            print('sending data to client')
            c.send(myStr.encode())


    if data[0] == '?' and data[1] == '0':
        print('executing home ')
        fileName = makeFile(data)
        if fileName is None:
            print('sending error message to client')
            c.send('Invalid PIN, no user found'.encode())
        else: c.send('P'.encode())                 # proceed
                


           
    if data == '': 
        print('nothing is recieved from client')
        break
    print('looping again, this data is recieved')
    print(data)
    print('now data is ')

    # print('hello aamir')
    addServices(data)
    data= ''
    
    
print('this data is recieved now ending of file')

print(l)
