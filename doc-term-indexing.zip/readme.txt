Note that dataset should be present in reuters21578 folder. the programm will load the files and will process it for creating inverted index

1: First we will run the invertedIndex.py file by 
$ python invertedIndex.py 
which will create the inverted index and will dump into the inverted_index.pkl file 

2: We will execute the phrase-query.py file, which will load the inverted index and will find the phrase thgrough processing the inverted index file, and will return the document Id in which the matched phrase is present.

3: We will execute the proximity-query.py file, which will load the inverted index file, will search the proximity query and will return the document ID in which the matched phrase is present.
