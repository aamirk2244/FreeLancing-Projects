import os
import string
import pickle


# Initialize the inverted index
inverted_index = {}


def add_to_index(doc_id, tokens):
    
    # Add the tokens of a document to the inverted index.
    
    for i, token in enumerate(tokens):
        if token not in inverted_index:
            inverted_index[token] = []
        inverted_index[token].append((doc_id, i))


def save_inverted_index():
    # Save the inverted index to a file
    with open('inverted_index.pkl', 'wb') as f:
        pickle.dump(inverted_index, f)


def preprocess(text):
    
    # Tokenize the text and perform normalization operations.
    
    text = text.lower()  # Convert the text to lowercase
    text = text.translate(str.maketrans('', '', string.punctuation))  # Remove punctuation
    tokens = text.split()  # Tokenize the text
    return tokens


def process_file(filename):
    
    # Process a single SGML file and extract the text of the news articles.
    
    with open(filename, 'r', encoding='latin-1') as f:
        text = f.read()
        i = 0
        while i < len(text):
            if text[i:i + 9] == '<REUTERS ':
                end_index = text.find('>', i + 9)
                reuters_tag = text[i + 9:end_index]
                doc_id = reuters_tag.split('NEWID="')[1].split('"')[0]
                title_start = text.find('<TITLE>', end_index)
                title_end = text.find('</TITLE>', title_start)
                title = text[title_start + len('<TITLE>'):title_end]
                body_start = text.find('<BODY>', title_end)
                body_end = text.find('</BODY>', body_start)
                body = text[body_start + len('<BODY>'):body_end]
                text = title + '\n' + body
                tokens = preprocess(text)
                add_to_index(doc_id, tokens)
            i += 1


def process_dataset(directory):
    
    # Process the entire Reuters-21578 dataset and build the inverted index.
    
    for filename in os.listdir(directory):
        if filename.endswith('.sgm'):
            file_path = os.path.join(directory, filename)
            process_file(file_path)


dataset_path = '/home/aamirk2244//AamirDrive/freelancing/documentRetrieval/reuters21578'
process_dataset(dataset_path)
save_inverted_index()

