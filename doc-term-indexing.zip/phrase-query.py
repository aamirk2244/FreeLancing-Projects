import pickle

def find_match(doc_pos, occured):
    # this function will check if the doc,pos present
    sequence_match = False
    for i in range(1, len(occured)):
        doc,pos = doc_pos
        if ((doc,pos+i)) in occured[i]: sequence_match = True
        else: sequence_match = False
    return sequence_match 
    
def process_phrase_query(query, inverted_index):
    query_terms = query.split()
    
    query_postings = [] # will contain the doc_id's of query phrase 
    for term in query_terms:
        if term in inverted_index:
            query_postings.append(set(doc_id for doc_id,pos in inverted_index[term]))
        else:
            return []
    
    result = sorted(list(set.intersection(*query_postings)))
    params = {}
    for l in query_terms:
        if l not in params: params[l] = []
        for doc,pos in inverted_index[l]:
            if doc in result: params[l].append((doc,pos))
    
            # dict_values([[(1, 2), (3, 0)], [(1, 4), (3, 3)]])
    
    found = []
    occured = list(params.values())
    
    for doc,pos in occured[0]:
        if find_match((doc,pos), occured): found.append(doc)
    return found # returning documents ID in which the phrase is present

with open('inverted_index.pkl', 'rb') as f:   
    inverted_index = pickle.load(f)
    
query = "old crop cocoa"
result = process_phrase_query(query, inverted_index)
print(result)


