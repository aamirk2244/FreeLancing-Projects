import pickle

# Load the inverted index from the saved file
with open('inverted_index.pkl', 'rb') as f:
    inverted_index = pickle.load(f)


def proximity_query(query, k=1):
    
    # Processing a proximity query of the form "w1 k w2".
    # Returns a list of document ids that match the query.
    
    query_terms = query.split()
    if len(query_terms) != 3:
        raise ValueError('Invalid query format')
    w1, k, w2 = query_terms
    if not k.isdigit():
        raise ValueError('Invalid query format')
    k = int(k)
    
    if w1 not in inverted_index or w2 not in inverted_index:
        return []
    
    matches = []
    first_doc_pos = inverted_index[w1]
    last_doc_pos = inverted_index[w2]    
    
    # Iterate through the positions of first word
    for w1_pos in first_doc_pos:
        doc_id = w1_pos[0]
        w1_index = w1_pos[1]
        # Look for positions of last word within k positions of first word
        for w2_pos in last_doc_pos:
            if w2_pos[0] == doc_id and ( abs(w1_index - w2_pos[1])-1 == k):
                matches.append(doc_id)
                break
    return matches
  
print(proximity_query("old 1 cocoa"))

